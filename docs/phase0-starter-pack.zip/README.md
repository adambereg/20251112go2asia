# Шаблоны и примеры для Фазы 0

Этот каталог содержит готовые шаблоны файлов для быстрого старта проекта.

---

## 📁 Структура

### Инфраструктурные файлы

- **`netlify.toml`** — Конфигурация Netlify для фронтенда
- **`wrangler.toml.example`** — Шаблон конфигурации Cloudflare Workers
- **`.github-workflows-pr-checks.yml`** — GitHub Actions workflow для PR проверок
- **`spectral.yaml`** — Конфигурация Spectral для валидации OpenAPI
- **`orval.config.ts`** — Конфигурация Orval для генерации типов и SDK
- **`next.config.js`** — Конфигурация Next.js для PWA shell

### OpenAPI спецификации

- **`openapi-content-example.yaml`** — Пример OpenAPI спецификации для Content Service
  - Содержит схемы ошибок, пагинацию, примеры endpoints
  - Использовать как основу для других сервисов

### Конфигурация окружений

- **`env-example.md`** — Шаблоны `.env.example` для всех капсул
  - Frontend, API Gateway, все сервисы
  - Правила хранения секретов

### Тесты

- **`cache-headers.test.ts`** — Тесты для проверки заголовков кеша
  - Проверка публичных endpoints (должны иметь кеш)
  - Проверка приватных endpoints (должны иметь no-store)

### SEO файлы

- **`app-sitemap.ts`** — Генератор sitemap.xml для Next.js
- **`app-robots.ts`** — Генератор robots.txt для Next.js
- **`og-metadata.tsx`** — Компонент для Open Graph метаданных
- **`lighthouse-budget.json`** — Бюджеты производительности для Lighthouse

---

## 📚 Дополнительная документация

### Операционные документы (`docs/ops/`)

- **`API_ERROR_POLICY.md`** — Политика ошибок API
  - Единый формат ответа об ошибке
  - Матрица HTTP кодов и кодов ошибок
  - Реализация в Gateway
  - Пагинация (cursor-based)

- **`BACKUP_RECOVERY.md`** — Playbook по бэкапам и восстановлению
  - Настройка PITR в Neon
  - Процесс восстановления (3 сценария)
  - Тестирование восстановления
  - RTO и RPO

- **`RATE_LIMIT_RULES.md`** — Правила rate limiting
  - Cloudflare Rate Limiting Rules (JSON экспорт)
  - Anti-abuse эвристики в сервисах
  - Мониторинг rate limiting

- **`RUNBOOKS.md`** — Runbooks для типичных инцидентов
  - P0: Критические инциденты
  - P1: Предупреждающие инциденты
  - SLO Dashboard
  - Правило "No Dashboards — No Prod"

---

## 🚀 Использование

### День 1: Инициализация

1. Скопировать `netlify.toml` в `apps/go2asia-pwa-shell/`
2. Скопировать `wrangler.toml.example` в каждый сервис как `wrangler.toml`
3. Скопировать `.github-workflows-pr-checks.yml` в `.github/workflows/pr-checks.yml`
4. Скопировать `spectral.yaml` в корень проекта
5. Скопировать `orval.config.ts` в корень проекта
6. Скопировать `next.config.js` в `apps/go2asia-pwa-shell/`

### День 2: OpenAPI

1. Использовать `openapi-content-example.yaml` как основу
2. Создать спецификации для всех сервисов:
   - `docs/openapi/content.yaml`
   - `docs/openapi/auth.yaml`
   - `docs/openapi/token.yaml`
   - `docs/openapi/referral.yaml`

### День 3: Конфигурация

1. Создать `.env.example` для каждой капсулы на основе `env-example.md`
2. Настроить секреты согласно правилам из `env-example.md`

### День 6: Тесты и SEO

1. Скопировать `cache-headers.test.ts` в `tests/`
2. Скопировать `app-sitemap.ts` в `apps/go2asia-pwa-shell/app/`
3. Скопировать `app-robots.ts` в `apps/go2asia-pwa-shell/app/`
4. Скопировать `og-metadata.tsx` в `apps/go2asia-pwa-shell/components/`
5. Скопировать `lighthouse-budget.json` в корень проекта

---

## ✅ Чек-лист использования шаблонов

- [ ] Все инфраструктурные файлы скопированы и настроены
- [ ] OpenAPI спецификации созданы на основе примера
- [ ] `.env.example` созданы для всех капсул
- [ ] Тесты для кеша добавлены
- [ ] SEO файлы добавлены
- [ ] Операционные документы изучены

---

**Последнее обновление:** 2025-11-09

