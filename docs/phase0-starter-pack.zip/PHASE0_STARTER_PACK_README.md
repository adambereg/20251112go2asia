# 📦 Go2Asia Phase 0 Starter Pack

**Версия:** 1.0  
**Дата:** 2025-11-09

Этот архив содержит все необходимые файлы, шаблоны и документацию для быстрого старта Фазы 0 проекта Go2Asia.

---

## 📋 Содержимое архива

### 📁 templates/ — Готовые шаблоны файлов

**Инфраструктурные файлы:**
- `netlify.toml` — Конфигурация Netlify для фронтенда
- `wrangler.toml.example` — Шаблон конфигурации Cloudflare Workers
- `.github-workflows-pr-checks.yml` — GitHub Actions workflow для PR проверок
- `spectral.yaml` — Конфигурация Spectral для валидации OpenAPI
- `orval.config.ts` — Конфигурация Orval для генерации типов и SDK
- `next.config.js` — Конфигурация Next.js для PWA shell

**OpenAPI примеры:**
- `openapi-content-example.yaml` — Пример OpenAPI спецификации с реальными схемами

**Конфигурация окружений:**
- `env-example.md` — Шаблоны `.env.example` для всех капсул

**Тесты:**
- `cache-headers.test.ts` — Тесты для проверки заголовков кеша

**SEO файлы:**
- `app-sitemap.ts` — Генератор sitemap.xml
- `app-robots.ts` — Генератор robots.txt
- `og-metadata.tsx` — Компонент Open Graph метаданных
- `lighthouse-budget.json` — Бюджеты производительности

**Документация:**
- `README.md` — Индекс всех шаблонов с инструкциями

### 📁 ops/ — Операционные документы

- `API_ERROR_POLICY.md` — Политика ошибок API (формат, коды, пагинация)
- `BACKUP_RECOVERY.md` — Playbook по бэкапам и восстановлению Neon
- `RATE_LIMIT_RULES.md` — Правила rate limiting и anti-abuse
- `RUNBOOKS.md` — Runbooks для типичных инцидентов (P0/P1)

### 📁 planning/ — Планирование

- `PHASE0_RESTART_PLAYBOOK.md` — Полный playbook Фазы 0 (1110 строк)
- `PHASE0_CHECKLIST.md` — Чек-лист прогресса по дням
- `CACHE_STRATEGY.md` — Стратегия кэширования с матрицей TTL

---

## 🚀 Быстрый старт

### Шаг 1: Распаковать архив

```bash
unzip phase0-starter-pack.zip -d go2asia-phase0/
cd go2asia-phase0/
```

### Шаг 2: Изучить документацию

1. **Начните с:** `planning/PHASE0_RESTART_PLAYBOOK.md`
   - Полное описание процесса Фазы 0
   - Определение готовности (DoD)
   - План на 7 дней

2. **Используйте чек-лист:** `planning/PHASE0_CHECKLIST.md`
   - Отмечайте прогресс по дням
   - Следите за выполнением задач

### Шаг 3: Использовать шаблоны

**День 1:**
- Скопировать `templates/netlify.toml` → `apps/go2asia-pwa-shell/netlify.toml`
- Скопировать `templates/wrangler.toml.example` → `services/*/wrangler.toml`
- Скопировать `.github-workflows-pr-checks.yml` → `.github/workflows/pr-checks.yml`
- Скопировать `templates/spectral.yaml` → `spectral.yaml`
- Скопировать `templates/orval.config.ts` → `orval.config.ts`
- Скопировать `templates/next.config.js` → `apps/go2asia-pwa-shell/next.config.js`

**День 2:**
- Использовать `templates/openapi-content-example.yaml` как основу
- Создать спецификации для всех сервисов

**День 3:**
- Создать `.env.example` на основе `templates/env-example.md`

**День 6:**
- Добавить тесты из `templates/cache-headers.test.ts`
- Добавить SEO файлы из `templates/`

### Шаг 4: Следовать операционным документам

- **Ошибки API:** `ops/API_ERROR_POLICY.md`
- **Бэкапы:** `ops/BACKUP_RECOVERY.md`
- **Rate limiting:** `ops/RATE_LIMIT_RULES.md`
- **Инциденты:** `ops/RUNBOOKS.md`

---

## 📊 Структура проекта после распаковки

```
go2asia-phase0/
├── templates/
│   ├── README.md
│   ├── netlify.toml
│   ├── wrangler.toml.example
│   ├── .github-workflows-pr-checks.yml
│   ├── spectral.yaml
│   ├── orval.config.ts
│   ├── next.config.js
│   ├── openapi-content-example.yaml
│   ├── env-example.md
│   ├── cache-headers.test.ts
│   ├── app-sitemap.ts
│   ├── app-robots.ts
│   ├── og-metadata.tsx
│   └── lighthouse-budget.json
├── ops/
│   ├── API_ERROR_POLICY.md
│   ├── BACKUP_RECOVERY.md
│   ├── RATE_LIMIT_RULES.md
│   └── RUNBOOKS.md
└── planning/
    ├── PHASE0_RESTART_PLAYBOOK.md
    ├── PHASE0_CHECKLIST.md
    └── CACHE_STRATEGY.md
```

---

## ✅ Чек-лист использования

- [ ] Архив распакован
- [ ] Изучен `PHASE0_RESTART_PLAYBOOK.md`
- [ ] Открыт `PHASE0_CHECKLIST.md` для отслеживания прогресса
- [ ] Все шаблоны скопированы в соответствующие места проекта
- [ ] Операционные документы изучены
- [ ] Готов к началу Фазы 0

---

## 📚 Дополнительные ресурсы

После завершения Фазы 0 изучите:
- `docs/reports/PROJECT_ANALYSIS_AND_OPTIMIZATION_REPORT.md` — Анализ проекта и рекомендации
- `docs/planning/MVP_ROADMAP.md` — Roadmap до MVP
- `docs/overview/go2asia-ecosystem.md` — Обзор экосистемы

---

## 🆘 Поддержка

При возникновении вопросов:
1. Проверьте соответствующий раздел в `PHASE0_RESTART_PLAYBOOK.md`
2. Изучите операционные документы в `ops/`
3. Проверьте примеры в `templates/`

---

**Удачи с Фазой 0! 🚀**

